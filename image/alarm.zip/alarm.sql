/*
-- Query: SELECT * FROM project.alarm
LIMIT 0, 1000

-- Date: 2018-09-03 12:48
*/
INSERT INTO `alarm` (`type`,`time`,`to`,`isFrom`,`readCheck`,`no`) VALUES ('writeArt','2018-08-27 10:35:06','test','test',0,6);
INSERT INTO `alarm` (`type`,`time`,`to`,`isFrom`,`readCheck`,`no`) VALUES ('writeArt','2018-08-27 10:45:01','test','test',1,7);
INSERT INTO `alarm` (`type`,`time`,`to`,`isFrom`,`readCheck`,`no`) VALUES ('writeArt','2018-08-27 11:33:45','test','test',1,8);
INSERT INTO `alarm` (`type`,`time`,`to`,`isFrom`,`readCheck`,`no`) VALUES ('writeArt','2018-08-28 10:59:49','test','test',1,9);
INSERT INTO `alarm` (`type`,`time`,`to`,`isFrom`,`readCheck`,`no`) VALUES ('writeArt','2018-08-28 11:05:58','test','test',1,10);
INSERT INTO `alarm` (`type`,`time`,`to`,`isFrom`,`readCheck`,`no`) VALUES ('writeArt','2018-08-28 11:27:20','test','test',1,11);
INSERT INTO `alarm` (`type`,`time`,`to`,`isFrom`,`readCheck`,`no`) VALUES ('writeArt','2018-08-28 11:28:38','test','test',1,12);
INSERT INTO `alarm` (`type`,`time`,`to`,`isFrom`,`readCheck`,`no`) VALUES ('writeArt','2018-08-28 16:47:56','artist2','artist2',1,13);
INSERT INTO `alarm` (`type`,`time`,`to`,`isFrom`,`readCheck`,`no`) VALUES ('writeArt','2018-08-28 17:35:09','artist2','artist2',0,14);
INSERT INTO `alarm` (`type`,`time`,`to`,`isFrom`,`readCheck`,`no`) VALUES ('writeArt','2018-08-30 14:58:34','test','test',0,15);
